﻿Partial Public Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub btnHitung_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnHitung.Click
        Try
            Dim intNilaiAbsensi As Integer
            Dim intNilaiKetertiban As Integer
            Dim intNilaiDisiplin As Integer
            Dim intNilaiRajin As Integer
            Dim intNilaiAkhir As Integer

            intNilaiAbsensi = (CInt(txtAbsen.Text) * 15) / 100
            intNilaiKetertiban = (CInt(txtTertib.Text) * 15) / 100
            intNilaiDisiplin = (CInt(txtDisip.Text) * 40) / 100
            intNilaiRajin = (CInt(txtRajin.Text) * 30) / 100

            intNilaiAkhir = intNilaiAbsensi + intNilaiKetertiban + intNilaiDisiplin + intNilaiRajin
            txtNilaiAkhir.Text = intNilaiAkhir
        Catch ex As Exception
        End Try
    End Sub
End Class