﻿Partial Public Class _Default
    Inherits System.Web.UI.Page
    Private db1GajihPokok As Double
    Private db1GajihBersih As Double
    Private dbTunjangan As Double
    Private db1pph As Double

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub btnCalculate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        Try

            If optStatus.SelectedValue = "K" Then
                db1GajihPokok = 2500000
                dbTunjangan = 750000
            ElseIf optStatus.SelectedValue = "T" Then
                db1GajihPokok = 3250000
                dbTunjangan = 1000000
            Else
                db1GajihPokok = 0
                dbTunjangan = 0
            End If

            db1pph = ((db1GajihPokok + dbTunjangan) * 5) / 100
            db1GajihBersih = (db1GajihPokok + dbTunjangan) - db1pph

            txtGajihPokok.Text = Format(db1GajihPokok, "#,##0.00")
            txtTunjangan.Text = Format(dbTunjangan, "#,##0.00")
            txtPph.Text = Format(db1pph, "#,##0.00")
            txtGajihBersih.Text = Format(db1GajihBersih, "#,##0.00")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtBagian.Text = ""
        txtGajihBersih.Text = ""
        txtGajihPokok.Text = ""
        txtJabatan.Text = ""
        txtNama.Text = ""
        txtNik.Text = ""
        txtPph.Text = ""
        txtTunjangan.Text = ""
    End Sub
End Class