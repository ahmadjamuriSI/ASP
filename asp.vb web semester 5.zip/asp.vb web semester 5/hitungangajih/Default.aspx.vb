﻿Partial Public Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub btnCalculate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        Try
            If tbNik.Text = "12345" Then
                tbNama.Text = "ahmad"
                tbBagian.Text = "qc"
                tbJabatan.Text = "staf"
                optStatus.Text = "kontrak"
                txtTunjangan.Text = "100,000,000"
                txtGajihBersih.Text = "10.000.000"
                txtGajihPokok.Text = "15.000.000"
                txtPph.Text = "10.000.000"

            ElseIf tbNik.Text = "12346" Then
                tbNama.Text = "umi"
                tbBagian.Text = "supervisor"
                tbJabatan.Text = "staf"
                optStatus.Text = "karyawan"
                txtTunjangan.Text = "100,000,000"
                txtGajihBersih.Text = "10.000.000"
                txtGajihPokok.Text = "15.000.000"
                txtPph.Text = "10.000.000"

            ElseIf tbNik.Text = "12347" Then
                tbNama.Text = "adi"
                tbBagian.Text = "supervisor"
                tbJabatan.Text = "staf"
                optStatus.Text = "karyawan"
                txtTunjangan.Text = "100,000,000"
                txtGajihBersih.Text = "10.000.000"
                txtGajihPokok.Text = "15.000.000"
                txtPph.Text = "10.000.000"

            Else
                MsgBox("kode spare part salah")
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class