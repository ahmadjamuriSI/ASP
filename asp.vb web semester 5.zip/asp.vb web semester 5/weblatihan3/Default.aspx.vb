﻿Partial Public Class _Default
    Inherits System.Web.UI.Page

    Private Sub BtnHitung_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnHitung.Click
        Try
            Dim Nilai1 As Integer
            Dim Nilai2 As Integer
            Dim Hasil As Integer
            Nilai1 = txtAngka1.Text
            Nilai2 = txtAngka2.Text
            Hasil = Nilai1 + Nilai2
            txtHasil.Text = Hasil


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class