﻿Partial Public Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub btnCalculate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        Try
            If txtkode.Text = "SP-101" Then
                txtNama.Text = "Oli Gardan"
                txtHarga.Text = 45000
            ElseIf txtkode.Text = "SP-102" Then
                txtNama.Text = "Oli Mesin"
                txtHarga.Text = 85000
            ElseIf txtkode.Text = "SP-103" Then
                txtNama.Text = "Ban Dalam Motor"
                txtHarga.Text = 105000
            Else
                MsgBox("kode spare part salah")
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class