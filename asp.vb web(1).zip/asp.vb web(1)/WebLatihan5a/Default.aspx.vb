﻿Partial Public Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub btnHitung_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnHitung.Click
        Try
            Dim dbHargaBarang As Double
            Dim intQuantity As Integer
            Dim dbDiscount As Double
            Dim db1JumlahBayar As Double

            dbHargaBarang = txtHarga.Text
            intQuantity = txtQty.Text
            If intQuantity > 10 Then
                dbDiscount = (dbHargaBarang * 10) / 100
            Else
                dbDiscount = 0
            End If
            txtDiscount.Text = dbDiscount

            db1JumlahBayar = (dbHargaBarang * intQuantity) - dbDiscount
            txtBayar.Text = Format(db1JumlahBayar, "#,##0.00")

        Catch ex As Exception

        End Try
    End Sub
End Class