﻿Partial Public Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub btnHitung_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnHitung.Click
        Try
            Dim dblHargaBarang As Double
            Dim intQuantity As Integer
            Dim dblDiscount As Double
            Dim dblJumlahBayar As Double

            dblHargaBarang = txtHarga.Text
            intQuantity = txtQuantity.Text
            If intQuantity > 10 Then
                dblDiscount = (dblHargaBarang * 20) / 100
            Else
                dblDiscount = 0
            End If
            txtDiscount.Text = dblDiscount

            dblJumlahBayar = (dblHargaBarang * intQuantity) - dblDiscount
            txtbayar.Text = Format(dblJumlahBayar, "#,##0.00")


        Catch ex As Exception

        End Try
    End Sub
End Class