﻿Partial Public Class _Default
    Inherits System.Web.UI.Page
    Private db1HargaBar As Double
    Private db1Diskon As Double
    Private db1Ppn As Double
    Private db1TotalHarga As Double

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub btnHitung_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnHitung.Click
        Try

            If UCase(txtkode.Text) = "A11" Then
                txtNamabar.Text = "Avanza"
                db1HargaBar = 200000000
                If optStatus.SelectedValue = "P" Then
                    db1Diskon = (db1HargaBar * 10) / 100
                Else
                    db1Diskon = 0
                End If


            ElseIf UCase(txtkode.Text) = "A12" Then
                txtNamabar.Text = "Sigra"
                db1HargaBar = 300000000
                If optStatus.SelectedValue = "P" Then
                    db1Diskon = (db1HargaBar * 11) / 100
                Else
                    db1Diskon = 0
                End If


            ElseIf UCase(txtkode.Text) = "A13" Then
                txtNamabar.Text = "Alya"
                db1HargaBar = 400000000
                If optStatus.SelectedValue = "P" Then
                    db1Diskon = (db1HargaBar * 12) / 100
                Else
                    db1Diskon = 0
                End If

            Else
                MsgBox("kode spare part salah")
                db1HargaBar = 0
                db1Diskon = 0
            End If
            db1Ppn = ((db1HargaBar - db1Diskon) * 20) / 100
            db1TotalHarga = (db1HargaBar + db1Ppn) - db1Diskon

            txtHargabar.Text = Format(db1HargaBar, "#,##0.00")
            txtDiskon.Text = Format(db1Diskon, "#,##0.00")
            txtPpn.Text = Format(db1Ppn, "#,##0.00")
            txtTotal.Text = Format(db1TotalHarga, "#,##0.00")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnHapus_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnHapus.Click
        txtDiskon.Text = ""
        txtHargabar.Text = ""
        txtkode.Text = ""
        txtNamabar.Text = ""
        txtPpn.Text = ""
        txtTotal.Text = ""
    End Sub
End Class