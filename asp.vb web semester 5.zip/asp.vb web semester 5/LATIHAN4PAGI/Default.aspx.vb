﻿Partial Public Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub btnHitung_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnHitung.Click
        Try
            Dim intNilaiAbsensi As Integer
            Dim intNilaiTugas As Integer
            Dim intNilaiUts As Integer
            Dim intNilaiUas As Integer
            Dim intNilaiAkhir As Integer

            intNilaiAbsensi = (CInt(txtAbsensi.Text) * 10) / 100
            intNilaiTugas = (CInt(txtTugas.Text) * 20) / 100
            intNilaiUts = (CInt(txtUts.Text) * 30) / 100
            intNilaiUas = (CInt(txtUas.Text) * 40) / 100

            intNilaiAkhir = intNilaiAbsensi + intNilaiTugas + intNilaiUts + intNilaiUas
            txtNilaiAkhir.Text = intNilaiAkhir


        Catch ex As Exception

        End Try
    End Sub
End Class