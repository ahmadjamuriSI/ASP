﻿
Partial Public Class _Default
    Inherits System.Web.UI.Page
    Private db1HargaBarang As Double
    Private db1Discount As Double
    Private db1Ppn As Double
    Private db1TotalHarga As Double

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub btnCalculate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        Try

            If UCase(txtkode.Text) = "SP-101" Then
                txtNama.Text = "Oli Gardan"
                db1HargaBarang = 45000
                If optStatus.SelectedValue = "P" Then
                    db1Discount = (db1HargaBarang * 5) / 100
                Else
                    db1Discount = 0
                End If


            ElseIf UCase(txtkode.Text) = "SP-102" Then
                txtNama.Text = "Oli Mesin"
                db1HargaBarang = 85000
                If optStatus.SelectedValue = "P" Then
                    db1Discount = (db1HargaBarang * 6) / 100
                Else
                    db1Discount = 0
                End If


            ElseIf UCase(txtkode.Text) = "SP-103" Then
                txtNama.Text = "Ban Dalam Motor"
                db1HargaBarang = 105000
                If optStatus.SelectedValue = "P" Then
                    db1Discount = (db1HargaBarang * 7) / 100
                Else
                    db1Discount = 0
                End If

            Else
                MsgBox("kode spare part salah")
                db1HargaBarang = 0
                db1Discount = 0
            End If
            db1Ppn = ((db1HargaBarang - db1Discount) * 10) / 100
            db1TotalHarga = (db1HargaBarang + db1Ppn) - db1Discount

            txtHarga.Text = Format(db1HargaBarang, "#,##0.00")
            txtDisc.Text = Format(db1Discount, "#,##0.00")
            txtPpn.Text = Format(db1Ppn, "#,##0.00")
            txtTotal.Text = Format(db1TotalHarga, "#,##0.00")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click
        txtDisc.Text = ""
        txtHarga.Text = ""
        txtkode.Text = ""
        txtNama.Text = ""
        txtPpn.Text = ""
        txtTotal.Text = ""
    End Sub
End Class